﻿    /*
    ** Watch_Face_Editor tool
    ** watchface js version v2.1.1
    ** Copyright © SashaCX75. All Rights Reserved
    */
   
    try {
    (() => {
        //start of ignored block
        const __$$app$$__ = __$$hmAppManager$$__.currentApp;
        function getApp() {
            return __$$app$$__.app;
        }
        function getCurrentPage() {
            return __$$app$$__.current && __$$app$$__.current.module;
        }
        const __$$module$$__ = __$$app$$__.current;
        const h = new DeviceRuntimeCore.WidgetFactory(new DeviceRuntimeCore.HmDomApi(__$$app$$__, __$$module$$__));
        const {px} = __$$app$$__.__globals__;
        const logger = Logger.getLogger('watchface_SashaCX75');
        //end of ignored block

        //dynamic modify start

        
        console.log('user_functions.js');
        // start user_functions.js

        let normal_sun_low_icon_img = ''
        let normal_sun_high_icon_img = ''
        let normal_tv_icon_img = ''
        let normal_altimeter_current_text = ''		
		
	const bodyTemperature = hmSensor.createSensor(hmSensor.id.BODY_TEMP);

	let bodyTempText		// текстовый виджет для температуры тела 

	  function updateBodyTemp() {
		const val =  bodyTemperature.current / 100
        bodyTempText.setProperty(hmUI.prop.TEXT, val.toFixed(1) + '°');		

	  }		

       let zona1_num = 0
       let zona1_all = 1
		function click_zona1() {
		  zona1_num = (zona1_num + 1) % (zona1_all + 1);
          if (zona1_num == 0) {	  
	      normal_sun_high_text_font.setProperty(hmUI.prop.VISIBLE, false);
          normal_sun_high_icon_img.setProperty(hmUI.prop.VISIBLE, false);		  
		  normal_sun_low_icon_img.setProperty(hmUI.prop.VISIBLE, true);		  
	      normal_sun_low_text_font.setProperty(hmUI.prop.VISIBLE, true);	
          };
          if (zona1_num == 1) {			  
	      normal_sun_high_text_font.setProperty(hmUI.prop.VISIBLE, true);
		  normal_sun_high_icon_img.setProperty(hmUI.prop.VISIBLE, true);		  
		  normal_sun_low_icon_img.setProperty(hmUI.prop.VISIBLE, false);
	      normal_sun_low_text_font.setProperty(hmUI.prop.VISIBLE, false);	
          };	  
		}
		
       let zona2_num = 0
       let zona2_all = 1
		function click_zona2() {
		  zona2_num = (zona2_num + 1) % (zona2_all + 1);
          if (zona2_num == 0) {	  
	      normal_altimeter_icon_img.setProperty(hmUI.prop.VISIBLE, true);
          normal_altitude_target_text_font.setProperty(hmUI.prop.VISIBLE, true);		  
		  normal_altimeter_current_text.setProperty(hmUI.prop.VISIBLE, true);		  
	      normal_temperature_current_text_font.setProperty(hmUI.prop.VISIBLE, false);
          normal_humidity_current_text_font.setProperty(hmUI.prop.VISIBLE, false);
          normal_tv_icon_img.setProperty(hmUI.prop.VISIBLE, false);	
		  Button_5.setProperty(hmUI.prop.VISIBLE, true);		  
          };
          if (zona2_num == 1) {			  
	      normal_altimeter_icon_img.setProperty(hmUI.prop.VISIBLE, false);
		  normal_altitude_target_text_font.setProperty(hmUI.prop.VISIBLE, false);		  
		  normal_altimeter_current_text.setProperty(hmUI.prop.VISIBLE, false);
	      normal_temperature_current_text_font.setProperty(hmUI.prop.VISIBLE, true);
          normal_humidity_current_text_font.setProperty(hmUI.prop.VISIBLE, true);
          normal_tv_icon_img.setProperty(hmUI.prop.VISIBLE, true);
		  Button_5.setProperty(hmUI.prop.VISIBLE, false);		  
          };	  
		}		
		
       let zona3_num = 0
       let zona3_all = 1
		function click_zona3() {
		  zona3_num = (zona3_num + 1) % (zona3_all + 1);
          if (zona3_num == 0) {	  
	      normal_spo2_icon_img.setProperty(hmUI.prop.VISIBLE, true);
          normal_spo2_current_text_font.setProperty(hmUI.prop.VISIBLE, true);		  
		  normal_heart_rate_icon_img.setProperty(hmUI.prop.VISIBLE, false);		  
	      normal_heart_rate_text_font.setProperty(hmUI.prop.VISIBLE, false);	
          };
          if (zona3_num == 1) {			  
	      normal_spo2_icon_img.setProperty(hmUI.prop.VISIBLE, false);
		  normal_spo2_current_text_font.setProperty(hmUI.prop.VISIBLE, false);		  
		  normal_heart_rate_icon_img.setProperty(hmUI.prop.VISIBLE, true);
	      normal_heart_rate_text_font.setProperty(hmUI.prop.VISIBLE, true);	
          };	  
		}		
		
       let zona4_num = 0
       let zona4_all = 1
		function click_zona4() {
		  zona4_num = (zona4_num + 1) % (zona4_all + 1);
          if (zona4_num == 0) {	 
		  normal_battery_current_text_font.setProperty(hmUI.prop.VISIBLE, true);		  
	      bodyTempText.setProperty(hmUI.prop.VISIBLE, false);		  	
          };
          if (zona4_num == 1) {
	      normal_battery_current_text_font.setProperty(hmUI.prop.VISIBLE, false);				  
	      bodyTempText.setProperty(hmUI.prop.VISIBLE, true);
          };	  
		}		
        // end user_functions.js

        let normal_background_bg_img = ''
        let normal_system_disconnect_img = ''
        let normal_battery_current_text_font = ''
        let normal_altimeter_icon_img = ''
        let normal_altitude_target_text_font = ''
        let normal_humidity_current_text_font = ''
        let normal_temperature_current_text_font = ''
        let normal_sun_low_text_font = ''
        let normal_sun_high_text_font = ''
        let normal_heart_rate_icon_img = ''
        let normal_heart_rate_text_font = ''
        let normal_spo2_icon_img = ''
        let normal_spo2_current_text_font = ''
        let normal_compass_direction_pointer_img = ''
        let normal_wind_direction_image_progress_img_level = ''
        let normal_dow_text_font = ''
        let normal_DOW_Array = ['ПН', 'ВТ', 'СР', 'ЧТ', 'ПТ', 'СБ', 'ВС'];
        let normal_day_month_font = ''
        let normal_timerTimeUpdate = undefined;
        let normal_time_hour_min_sec_text_font = ''
        let idle_background_bg_img = ''
        let idle_system_disconnect_img = ''
        let idle_battery_current_text_font = ''
        let idle_dow_text_font = ''
        let idle_DOW_Array = ['ПН', 'ВТ', 'СР', 'ЧТ', 'ПТ', 'СБ', 'ВС'];
        let idle_day_month_font = ''
        let idle_timerTimeUpdate = undefined;
        let idle_time_hour_min_text_font = ''
        let Button_1 = ''
        let Button_2 = ''
        let Button_3 = ''
        let Button_4 = ''
        let Button_5 = ''
        let timeSensor = '';


        //dynamic modify end

        __$$module$$__.module = DeviceRuntimeCore.WatchFace({
            init_view() {
                //dynamic modify start
                    
                
            // FontName: Eurostile-Med.ttf; FontSize: 48
            hmUI.createWidget(hmUI.widget.TEXT, {
              x: 478,
              y: 478,
              w: 706,
              h: 64,
              text_size: 48,
              char_space: 0,
              line_space: 0,
              font: 'fonts/Eurostile-Med.ttf',
              color: 0xFFFFFFFF,
              align_h: hmUI.align.CENTER_H,
              align_v: hmUI.align.CENTER_V,
              text_style: hmUI.text_style.ELLIPSIS,
              text: "0123456789 _-.,:;`'%°\\/",
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            // FontName: Eurostile-Med.ttf; FontSize: 52
            hmUI.createWidget(hmUI.widget.TEXT, {
              x: 478,
              y: 478,
              w: 762,
              h: 70,
              text_size: 52,
              char_space: 0,
              line_space: 0,
              font: 'fonts/Eurostile-Med.ttf',
              color: 0xFFFFFFFF,
              align_h: hmUI.align.CENTER_H,
              align_v: hmUI.align.CENTER_V,
              text_style: hmUI.text_style.ELLIPSIS,
              text: "0123456789 _-.,:;`'%°\\/",
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            // FontName: Eurostile-Med.ttf; FontSize: 53; Cache: full
            hmUI.createWidget(hmUI.widget.TEXT, {
              x: 478,
              y: 478,
              w: 63,
              h: 63,
              text_size: 53,
              char_space: 0,
              line_space: 0,
              font: 'fonts/Eurostile-Med.ttf',
              color: 0xFFFFFFFF,
              align_h: hmUI.align.LEFT,
              align_v: hmUI.align.TOP,
              text_style: hmUI.text_style.NONE,
              text: "0123456789 ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz АБВГДЕЁЖЗИЙКЛМНОПРСТУФХЦЧШЩЪЫЬЭЮЯабвгдеёжзийклмнопрстуфхцчшщъыьэюя  ҐЄІЇґєії _-.,:;`'%°\\/",
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            // FontName: Eurostile-Med.ttf; FontSize: 90
            hmUI.createWidget(hmUI.widget.TEXT, {
              x: 478,
              y: 478,
              w: 1320,
              h: 121,
              text_size: 90,
              char_space: 0,
              line_space: 0,
              font: 'fonts/Eurostile-Med.ttf',
              color: 0xFFFFFFFF,
              align_h: hmUI.align.CENTER_H,
              align_v: hmUI.align.CENTER_V,
              text_style: hmUI.text_style.ELLIPSIS,
              text: "0123456789 _-.,:;`'%°\\/",
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            // FontName: Eurostile-Med.ttf; FontSize: 120
            hmUI.createWidget(hmUI.widget.TEXT, {
              x: 478,
              y: 478,
              w: 1771,
              h: 162,
              text_size: 120,
              char_space: 0,
              line_space: 0,
              font: 'fonts/Eurostile-Med.ttf',
              color: 0xFFFFFFFF,
              align_h: hmUI.align.CENTER_H,
              align_v: hmUI.align.CENTER_V,
              text_style: hmUI.text_style.ELLIPSIS,
              text: "0123456789 _-.,:;`'%°\\/",
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            console.log('user_script_start.js');
            // start user_script_start.js

	class AdvancedBarometer {
	  constructor(props = {}) {
		this.props = {
			unit_index: hmFS.SysProGetInt('BaroUnitIndex') ?? 0,		// текущий индекс единицы измерения (сохраняется и считывается из памяти): 0 - мм рт.ст., 1 - гПа
			show_toast: true,											// показывать всплывающее сообщение при переключении единицы измерения
			widget: null,												// виджет TEXT для отображения давления
			show_trend: true,											// показывать тренд (растет, падает) после значения давления при обновлении виджета
			time_sensor: null,											// сенсор времени (для обновления давления), если не задан, то создается новый
			auto_update: true,											// автоматическое обновление погоды (нет необходимости добавлять метод .update() в event.MINUTEEND и WIDGET_DELEGATE)
			lang: hmSetting.getLanguage() == 4 ? 0 : 1,					// языка устройства	(Русский = 0 / Английский = 1)
			...props,
		};

		this.unitStr = [	['мм рт.ст.',  'mmHg'],		// 0
							['гПа',  'hPa'],			// 1	
						]

		this.last = {
			value: '--',
			trend: '',
		}

		if (!this.props.time_sensor) this.props.time_sensor = hmSensor.createSensor(hmSensor.id.TIME);
		if (isFinite(props.unit_index)) hmFS.SysProSetInt('BaroUnitIndex', props.unit_index);
		if (this.props.auto_update) this.createHandlers();
	  }

	// создание обработчиков автоматического обновления давления
		createHandlers() {
			this.props.time_sensor.addEventListener(this.props.time_sensor.event.MINUTEEND, () => this.update());

			this.widgetDelegate = hmUI.createWidget(hmUI.widget.WIDGET_DELEGATE, {
			  resume_call: ( () => this.update() )
			})
		}

	// чтение файла с данными атмосферного давления
		readDataFile() {		
			const file_name_alt = "../../../baro_altim/pressure.dat";
			const [fs_stat, err] = hmFS.stat(file_name_alt);
			if (err == 0) {
			  let file_size = fs_stat.size;
			  const len = file_size / 4;
			  const fh = hmFS.open(file_name_alt, hmFS.O_RDONLY)
			  let array_buffer = new Float32Array(len);
			  hmFS.read(fh, array_buffer.buffer, 0, file_size);
			  hmFS.close(fh);
			  return array_buffer;
			} else {
			  console.log('err:', err)
			}
			return null
		}
			
	// получение последнего значения в массиве данных из файла
		getLastValue(data_array) {
			if(!data_array?.length) return null;
			
			const start = data_array.length - 1;
			let end = start - 30 * 3; // 3 часа
			if(end < 0) end = 0;
			
			for (let i = start; i >= end; i--) {
			  if(data_array[i] != 0) return parseInt(data_array[i] / 100);
			}
			
			return null
		}
	
	// получение изменения давления
		getPressureChange(data_array) {
			if(!data_array?.length) return null;
			const start = data_array.length - 1;
			let end = start - 30 * 3; // 3 часа
			if(end < 0) end = 0;

			let value = data_array[start];

			for (let i = start - 1; i >= end; i--) {
			  let element = data_array[i];
			  if(element != 0) {
				if(Math.abs(value - element) > 75) { // учитываем только если разница больше 0,75 hPa ~ 1 мм рт.ст.
				  value = value - element;
				  return value;
				}
			  }
			}
			return null
		}

	// получить текущее значения  давления и тренда
		getPressureAndTrend(){
			const data_array = this.readDataFile();
			const value = this.getLastValue(data_array);

			let trend = ''; //	"•"
			const pressureChange = this.getPressureChange(data_array);
			if (pressureChange < 0) trend = "↓";
			else if (pressureChange > 0) trend = "↑";

			return {value, trend}
		}

	// установить единицы измерения по индексу: 0 - мм рт.ст., 1 - гПа
		setUnits(unit_index) {
			if(!isFinite(unit_index)) return
			this.props.unit_index = unit_index == 1 ? 1 : 0;
			hmFS.SysProSetInt('BaroUnitIndex', this.props.unit_index);
			if (this.props.widget) this.updateWidget();
		}

	// переключить единицы измерения на следующие по кругу
		toggleUnits(show_toast = this.props.show_toast) {
			const newIndex = (this.props.unit_index + 1) % this.unitStr.length;
			this.setUnits(newIndex);
			if (show_toast) hmUI.showToast({text: this.unit});
		}

	// обновить показания давления и виджет
		update() {
			const {value, trend}  = this.getPressureAndTrend();
			if (value != this.last.value){
				this.last.value = value;
				this.last.trend = trend;
				if (this.props.widget) this.updateWidget();
			}
		}

	// обновить виджет
		updateWidget() {
			let str = this.pressure;
			if (this.props.show_trend) str += ` ${this.last.trend}`;
			this.props.widget.setProperty(hmUI.prop.TEXT, str);
		}

	// получить текущее значение давление в мм рт. ст.
		get mmHg() {
			let v = this.last.value;
			if (!(v)) return '--'
			else v *= 0.750064;
			return Math.round(v).toString();
		}

	// получить текущее значение давление в гПа
		get hPa() {
			let v = this.last.value;
			if (!(v)) return '--'
			return this.last.value
		}

	// получить давление в текущих единицах измерения
		get pressure() {
			if (this.props.unit_index == 0) return this.mmHg
			else return this.hPa
		}

	// получить название текущей единицы измерения
		get unit() {
			return this.unitStr[this.props.unit_index][this.props.lang]
		}

	// получить индекс текущей единицы измерения
		get unit_index() {
			return this.props.unit_index
		}

	// получить тренд
		get trend() {
			return this.last.trend
		}

	// удалить
	  delete() {
		this.props = null;
		this.last = null;
		this.unitStr = null;
		if (this.widgetDelegate) {
			hmUI.deleteWidget(this.widgetDelegate);
			this.widgetDelegate = null;
		}
	  }

	}
            // end user_script_start.js

            console.log('Watch_Face.ScreenNormal');
            normal_background_bg_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              w: 480,
              h: 480,
              src: 'bg_1.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_system_disconnect_img = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
              x: 0,
              y: 0,
              src: 'btOff.png',
              type: hmUI.system_status.DISCONNECT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_battery_current_text_font = hmUI.createWidget(hmUI.widget.TEXT_FONT, {
              x: 140,
              y: 408,
              w: 200,
              h: 50,
              text_size: 48,
              char_space: 0,
              line_space: 0,
              font: 'fonts/Eurostile-Med.ttf',
              color: 0xFFFFFFFF,
              align_h: hmUI.align.CENTER_H,
              align_v: hmUI.align.CENTER_V,
              unit_type: 1,
              text_style: hmUI.text_style.ELLIPSIS,
              type: hmUI.data_type.BATTERY,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            console.log('user_script.js');
            // start user_script.js
            normal_sun_high_icon_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 291,
              y: 307,
              src: 'icon_voshod.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });
			
            normal_sun_low_icon_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 291,
              y: 307,
              src: 'icon_zakat.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });	

            normal_tv_icon_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 78,
              y: 117,
              src: 'icon_tv.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });	

	bodyTempText = hmUI.createWidget(hmUI.widget.TEXT, {
              x: 143,
              y: 408,
              w: 200,
              h: 50,
              text_size: 48,
              char_space: 0,
              line_space: 0,
              font: 'fonts/Eurostile-Med.ttf',
              color: 0xFFFFFFFF,
	  align_h: hmUI.align.CENTER_H,
	  align_v: hmUI.align.CENTER_V,
	  text_style: hmUI.text_style.ELLIPSIS,
	});	

            normal_altimeter_current_text = hmUI.createWidget(hmUI.widget.TEXT, {
              x: 254,
              y: 150,
              w: 180,
              h: 52,
              text_size: 52,
              char_space: 0,
              line_space: 0,
              font: 'fonts/Eurostile-Med.ttf',
              color: 0xFFFFFFFF,
              align_h: hmUI.align.CENTER_H,
              align_v: hmUI.align.CENTER_V,
              text_style: hmUI.text_style.ELLIPSIS,
              type: hmUI.data_type.ALTIMETER,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });	
			
        // экземпляр класса
            const barometer = new AdvancedBarometer({
	        widget: normal_altimeter_current_text,
        });			
			
			
            // end user_script.js

            normal_altimeter_icon_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 78,
              y: 117,
              src: 'icon_dv.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_altitude_target_text_font = hmUI.createWidget(hmUI.widget.TEXT_FONT, {
              x: 45,
              y: 150,
              w: 174,
              h: 52,
              text_size: 52,
              char_space: 0,
              line_space: 0,
              font: 'fonts/Eurostile-Med.ttf',
              color: 0xFFFFFFFF,
              align_h: hmUI.align.CENTER_H,
              align_v: hmUI.align.CENTER_V,
              text_style: hmUI.text_style.ELLIPSIS,
              type: hmUI.data_type.ALTITUDE,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_humidity_current_text_font = hmUI.createWidget(hmUI.widget.TEXT_FONT, {
              x: 262,
              y: 150,
              w: 160,
              h: 52,
              text_size: 52,
              char_space: 0,
              line_space: 0,
              font: 'fonts/Eurostile-Med.ttf',
              color: 0xFFFFFFFF,
              align_h: hmUI.align.CENTER_H,
              align_v: hmUI.align.CENTER_V,
              unit_type: 1,
              text_style: hmUI.text_style.ELLIPSIS,
              type: hmUI.data_type.HUMIDITY,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_temperature_current_text_font = hmUI.createWidget(hmUI.widget.TEXT_FONT, {
              x: 48,
              y: 150,
              w: 174,
              h: 52,
              text_size: 52,
              char_space: 1,
              line_space: 0,
              font: 'fonts/Eurostile-Med.ttf',
              color: 0xFFFFFFFF,
              align_h: hmUI.align.CENTER_H,
              align_v: hmUI.align.CENTER_V,
              unit_type: 1,
              text_style: hmUI.text_style.ELLIPSIS,
              type: hmUI.data_type.WEATHER_CURRENT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_sun_low_text_font = hmUI.createWidget(hmUI.widget.TEXT_FONT, {
              x: 260,
              y: 342,
              w: 150,
              h: 50,
              text_size: 52,
              char_space: 0,
              line_space: 0,
              font: 'fonts/Eurostile-Med.ttf',
              color: 0xFFFFFFFF,
              align_h: hmUI.align.CENTER_H,
              align_v: hmUI.align.CENTER_V,
              text_style: hmUI.text_style.ELLIPSIS,
              type: hmUI.data_type.SUN_SET,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_sun_high_text_font = hmUI.createWidget(hmUI.widget.TEXT_FONT, {
              x: 260,
              y: 342,
              w: 150,
              h: 50,
              text_size: 52,
              char_space: 0,
              line_space: 0,
              font: 'fonts/Eurostile-Med.ttf',
              color: 0xFFFFFFFF,
              align_h: hmUI.align.CENTER_H,
              align_v: hmUI.align.CENTER_V,
              text_style: hmUI.text_style.ELLIPSIS,
              type: hmUI.data_type.SUN_RISE,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_heart_rate_icon_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 88,
              y: 309,
              src: 'icon_puls.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_heart_rate_text_font = hmUI.createWidget(hmUI.widget.TEXT_FONT, {
              x: 66,
              y: 342,
              w: 160,
              h: 50,
              text_size: 52,
              char_space: 0,
              line_space: 0,
              font: 'fonts/Eurostile-Med.ttf',
              color: 0xFFFFFFFF,
              align_h: hmUI.align.CENTER_H,
              align_v: hmUI.align.CENTER_V,
              text_style: hmUI.text_style.ELLIPSIS,
              type: hmUI.data_type.HEART,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_spo2_icon_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 88,
              y: 309,
              src: 'icon_spo2.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_spo2_current_text_font = hmUI.createWidget(hmUI.widget.TEXT_FONT, {
              x: 66,
              y: 342,
              w: 160,
              h: 50,
              text_size: 52,
              char_space: 0,
              line_space: 0,
              font: 'fonts/Eurostile-Med.ttf',
              color: 0xFFFFFFFF,
              align_h: hmUI.align.CENTER_H,
              align_v: hmUI.align.CENTER_V,
              unit_type: 1,
              text_style: hmUI.text_style.ELLIPSIS,
              type: hmUI.data_type.SPO2,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            const deviceInfo = hmSetting.getDeviceInfo();
            
            // normal_compass_custom_pointer_img = hmUI.createWidget(hmUI.widget.CUSTOM_POINTER, {
              // src: 'compass.png',
              // center_x: 240,
              // center_y: 240,
              // x: 240,
              // y: 240,
              // start_angle: 0,
              // end_angle: 360,
              // type: hmUI.data_type.COMPASS,
              // show_level: hmUI.show_level.ONLY_NORMAL,
            // });


            //start of ignored block
            normal_compass_direction_pointer_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              w: deviceInfo.width,
              h: deviceInfo.height,
              pos_x: 240 - 240,
              pos_y: 240 - 240,
              center_x: 240,
              center_y: 240,
              src: 'compass.png',
              angle: 0,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });
            //end of ignored block

            normal_wind_direction_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 0,
              y: 0,
              image_array: ["windD_1.png","windD_2.png","windD_3.png","windD_4.png","windD_5.png","windD_6.png","windD_7.png","windD_8.png"],
              image_length: 8,
              type: hmUI.data_type.WIND_DIRECTION,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            if (!timeSensor) timeSensor = hmSensor.createSensor(hmSensor.id.TIME);
            timeSensor.addEventListener(timeSensor.event.DAYCHANGE, function() {
              time_update(true);
            });

            normal_dow_text_font = hmUI.createWidget(hmUI.widget.TEXT, {
              x: 134,
              y: 48,
              w: 80,
              h: 52,
              text_size: 53,
              char_space: 0,
              line_space: 0,
              font: 'fonts/Eurostile-Med.ttf',
              color: 0xFFFFFFFF,
              align_h: hmUI.align.LEFT,
              align_v: hmUI.align.TOP,
              text_style: hmUI.text_style.ELLIPSIS,
              // unit_string: ПН, ВТ, СР, ЧТ, ПТ, СБ, ВС,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            let screenType = hmSetting.getScreenType();
            normal_day_month_font = hmUI.createWidget(hmUI.widget.TEXT, {
              x: 207,
              y: 52,
              w: 160,
              h: 52,
              text_size: 53,
              char_space: 0,
              line_space: 0,
              font: 'fonts/Eurostile-Med.ttf',
              color: 0xFFFFFFFF,
              align_h: hmUI.align.CENTER_H,
              align_v: hmUI.align.CENTER_V,
              text_style: hmUI.text_style.ELLIPSIS,
              // padding: true,
              // unit_type: 1,
              // unit_string: .,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_time_hour_min_sec_text_font = hmUI.createWidget(hmUI.widget.TEXT, {
              x: 0,
              y: 215,
              w: 480,
              h: 90,
              text_size: 90,
              char_space: 0,
              line_space: 0,
              font: 'fonts/Eurostile-Med.ttf',
              color: 0xFFFFFFFF,
              align_h: hmUI.align.CENTER_H,
              align_v: hmUI.align.CENTER_V,
              text_style: hmUI.text_style.ELLIPSIS,
              // padding: true,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });


            console.log('Watch_Face.ScreenAOD');
            idle_background_bg_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              w: 480,
              h: 480,
              src: 'bg_AOD.png',
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_system_disconnect_img = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
              x: 120,
              y: 330,
              src: 'bt_off.png',
              type: hmUI.system_status.DISCONNECT,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_battery_current_text_font = hmUI.createWidget(hmUI.widget.TEXT_FONT, {
              x: 160,
              y: 404,
              w: 160,
              h: 50,
              text_size: 48,
              char_space: 0,
              line_space: 0,
              font: 'fonts/Eurostile-Med.ttf',
              color: 0xFFFFFFFF,
              align_h: hmUI.align.CENTER_H,
              align_v: hmUI.align.CENTER_V,
              unit_type: 1,
              text_style: hmUI.text_style.ELLIPSIS,
              type: hmUI.data_type.BATTERY,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_dow_text_font = hmUI.createWidget(hmUI.widget.TEXT, {
              x: 126,
              y: 96,
              w: 80,
              h: 52,
              text_size: 53,
              char_space: 0,
              line_space: 0,
              font: 'fonts/Eurostile-Med.ttf',
              color: 0xFFFFFFFF,
              align_h: hmUI.align.LEFT,
              align_v: hmUI.align.TOP,
              text_style: hmUI.text_style.ELLIPSIS,
              // unit_string: ПН, ВТ, СР, ЧТ, ПТ, СБ, ВС,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_day_month_font = hmUI.createWidget(hmUI.widget.TEXT, {
              x: 199,
              y: 100,
              w: 160,
              h: 52,
              text_size: 53,
              char_space: 0,
              line_space: 0,
              font: 'fonts/Eurostile-Med.ttf',
              color: 0xFFFFFFFF,
              align_h: hmUI.align.CENTER_H,
              align_v: hmUI.align.CENTER_V,
              text_style: hmUI.text_style.ELLIPSIS,
              // padding: true,
              // unit_type: 1,
              // unit_string: .,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_time_hour_min_text_font = hmUI.createWidget(hmUI.widget.TEXT, {
              x: 69,
              y: 194,
              w: 340,
              h: 120,
              text_size: 120,
              char_space: 0,
              line_space: 0,
              font: 'fonts/Eurostile-Med.ttf',
              color: 0xFFFFFFFF,
              align_h: hmUI.align.CENTER_H,
              align_v: hmUI.align.CENTER_V,
              text_style: hmUI.text_style.ELLIPSIS,
              // padding: true,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            console.log('Watch_Face.Buttons');
            Button_1 = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 263,
              y: 337,
              w: 140,
              h: 50,
              text: '',
              color: 0xFFFF8C00,
              text_size: 25,
              press_src: 'empty.png',
              normal_src: 'empty.png',
              click_func: (button_widget) => {
                click_zona1();
              }, // end func
              show_level: hmUI.show_level.ONLY_NORMAL,
            }); // end button

            Button_2 = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 83,
              y: 147,
              w: 122,
              h: 50,
              text: '',
              color: 0xFFFF8C00,
              text_size: 25,
              press_src: 'empty.png',
              normal_src: 'empty.png',
              click_func: (button_widget) => {
                click_zona2();
              }, // end func
              show_level: hmUI.show_level.ONLY_NORMAL,
            }); // end button

            Button_3 = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 85,
              y: 337,
              w: 126,
              h: 50,
              text: '',
              color: 0xFFFF8C00,
              text_size: 25,
              press_src: 'empty.png',
              normal_src: 'empty.png',
              click_func: (button_widget) => {
                click_zona3();
              }, // end func
              show_level: hmUI.show_level.ONLY_NORMAL,
            }); // end button

            Button_4 = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 177,
              y: 409,
              w: 126,
              h: 50,
              text: '',
              color: 0xFFFF8C00,
              text_size: 25,
              press_src: 'empty.png',
              normal_src: 'empty.png',
              click_func: (button_widget) => {
                click_zona4();
              }, // end func
              show_level: hmUI.show_level.ONLY_NORMAL,
            }); // end button

            Button_5 = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 275,
              y: 149,
              w: 126,
              h: 50,
              text: '',
              color: 0xFFFF8C00,
              text_size: 25,
              press_src: 'empty.png',
              normal_src: 'empty.png',
              click_func: (button_widget) => {
                barometer.toggleUnits();
              }, // end func
              show_level: hmUI.show_level.ONLY_NORMAL,
            }); // end button

            console.log('user_script_end.js');
            // start user_script_end.js

       if (screenType != hmSetting.screen_type.AOD) {
	      normal_sun_high_text_font.setProperty(hmUI.prop.VISIBLE, false);
          normal_sun_high_icon_img.setProperty(hmUI.prop.VISIBLE, false);
	      normal_temperature_current_text_font.setProperty(hmUI.prop.VISIBLE, false);
          normal_humidity_current_text_font.setProperty(hmUI.prop.VISIBLE, false);
          normal_tv_icon_img.setProperty(hmUI.prop.VISIBLE, false);	
		  normal_heart_rate_icon_img.setProperty(hmUI.prop.VISIBLE, false);		  
	      normal_heart_rate_text_font.setProperty(hmUI.prop.VISIBLE, false);
	      bodyTempText.setProperty(hmUI.prop.VISIBLE, false);		  
        };
            // end user_script_end.js

            //start of ignored block
            function time_update(updateHour = false, updateMinute = false) {
              console.log('time_update()');
              let hour = timeSensor.hour;
              let minute = timeSensor.minute;
              let second = timeSensor.second;
              let format_hour = timeSensor.format_hour;

              console.log('day of week font');
              if (updateHour) {
                let normal_DOW_Str = normal_DOW_Array[timeSensor.week-1];
                normal_dow_text_font.setProperty(hmUI.prop.TEXT, normal_DOW_Str );
              };

              console.log('day/month font');
              if (updateHour) {
                let normal_DayStr = timeSensor.day.toString();
                let normal_MonthStr = timeSensor.month.toString();
                normal_DayStr = normal_DayStr.padStart(2, '0');
                normal_MonthStr = normal_MonthStr.padStart(2, '0');
                let normal_DayMonthStr = '--';
                const dateFormat = hmSetting.getDateFormat();
                if (dateFormat == 0 || dateFormat == 2) {
                  normal_DayMonthStr = normal_MonthStr + '.' + normal_DayStr;
                }
                if (dateFormat == 1) {
                  normal_DayMonthStr = normal_DayStr + '.' + normal_MonthStr;
                }
                normal_day_month_font.setProperty(hmUI.prop.TEXT, normal_DayMonthStr );
              };

              console.log('hour:min:sec font');
              let normal_HourMinSecStr = format_hour.toString();
              normal_HourMinSecStr = normal_HourMinSecStr.padStart(2, '0');
              normal_HourMinSecStr = normal_HourMinSecStr + ':' + minute.toString().padStart(2, '0') + ':' + second.toString().padStart(2, '0');
              if (!timeSensor.is24Hour) {
                if (hour > 11) normal_HourMinSecStr = 'pm ' + normal_HourMinSecStr
                else normal_HourMinSecStr = 'am ' + normal_HourMinSecStr
              };
              normal_time_hour_min_sec_text_font.setProperty(hmUI.prop.TEXT, normal_HourMinSecStr );
              console.log('day of week font');
              if (updateHour) {
                let idle_DOW_Str = idle_DOW_Array[timeSensor.week-1];
                idle_dow_text_font.setProperty(hmUI.prop.TEXT, idle_DOW_Str );
              };

              console.log('day/month font');
              if (updateHour) {
                let idle_DayStr = timeSensor.day.toString();
                let idle_MonthStr = timeSensor.month.toString();
                idle_DayStr = idle_DayStr.padStart(2, '0');
                idle_MonthStr = idle_MonthStr.padStart(2, '0');
                let idle_DayMonthStr = '--';
                const dateFormat = hmSetting.getDateFormat();
                if (dateFormat == 0 || dateFormat == 2) {
                  idle_DayMonthStr = idle_MonthStr + '.' + idle_DayStr;
                }
                if (dateFormat == 1) {
                  idle_DayMonthStr = idle_DayStr + '.' + idle_MonthStr;
                }
                idle_day_month_font.setProperty(hmUI.prop.TEXT, idle_DayMonthStr );
              };

              console.log('hour:min font');
              if (updateMinute) {
                let idle_HourMinStr = format_hour.toString();
                idle_HourMinStr = idle_HourMinStr.padStart(2, '0');
                idle_HourMinStr = idle_HourMinStr + ':' + minute.toString().padStart(2, '0')
                if (!timeSensor.is24Hour) {
                  if (hour > 11) idle_HourMinStr = 'pm ' + idle_HourMinStr
                  else idle_HourMinStr = 'am ' + idle_HourMinStr
                };
                idle_time_hour_min_text_font.setProperty(hmUI.prop.TEXT, idle_HourMinStr );
              };

            };

            //end of ignored block
            //start of ignored block
            console.log('compass_update()');
            if (screenType == hmSetting.screen_type.WATCHFACE){
              compass = hmSensor.createSensor(hmSensor.id.COMPASS);
              compass.start();

              if (compass.direction_angle && compass.direction  && compass.direction_angle != 'INVALID') { // initial data
                // Compass Pointer
                let compass_direction_angle = parseInt(compass.direction_angle);
                normal_compass_direction_pointer_img.setProperty(hmUI.prop.ANGLE, -compass_direction_angle);

              } else { // error data
                normal_compass_direction_pointer_img.setProperty(hmUI.prop.ANGLE, 0);

              }

              compass.addEventListener(hmSensor.event.CHANGE, function (compass_res) { // change values when changing direction

                if (compass_res.calibration_status) {
                  // Compass Pointer
                  let compass_direction_angle = parseInt(compass_res.direction_angle);
                  normal_compass_direction_pointer_img.setProperty(hmUI.prop.ANGLE, -compass_direction_angle);

                } else { // error data
                  normal_compass_direction_pointer_img.setProperty(hmUI.prop.ANGLE, 0);

                }

              }); // Listener end

            };
            //end of ignored block

            const widgetDelegate = hmUI.createWidget(hmUI.widget.WIDGET_DELEGATE, {
              resume_call: (function () {
                console.log('resume_call()');
                time_update(true, true);
                if (compass && screenType == hmSetting.screen_type.WATCHFACE) compass.start();
                if (screenType == hmSetting.screen_type.WATCHFACE) {
                  if (!normal_timerTimeUpdate) {
                    normal_timerTimeUpdate = timer.createTimer(0, 1000, (function (option) {
                      let updateHour = timeSensor.minute == 0;
                      let updateMinute = timeSensor.second < 2;
                      time_update(updateHour, updateMinute);
                    }));  // end timer 
                  };  // end timer check
                };  // end screenType

                if (screenType == hmSetting.screen_type.AOD) {
                  if (!idle_timerTimeUpdate) {
                    idle_timerTimeUpdate = timer.createTimer(0, 1000, (function (option) {
                      let updateHour = timeSensor.minute == 0;
                      let updateMinute = timeSensor.second < 2;
                      time_update(updateHour, updateMinute);
                    }));  // end timer 
                  };  // end timer check
                };  // end screenType


                console.log('resume_call.js');
                // start resume_call.js

		updateBodyTemp();
                // end resume_call.js

              }),
              pause_call: (function () {
                console.log('pause_call()');
                if (compass) compass.stop();
                if (normal_timerTimeUpdate) {
                  timer.stopTimer(normal_timerTimeUpdate);
                  normal_timerTimeUpdate = undefined;
                }
                if (idle_timerTimeUpdate) {
                  timer.stopTimer(idle_timerTimeUpdate);
                  idle_timerTimeUpdate = undefined;
                }

              }),
            });

                //dynamic modify end
            },
            onInit() {
                logger.log('index page.js on init invoke');
            },
            build() {
                this.init_view();
                logger.log('index page.js on ready invoke');
            },
            onDestroy() {
                logger.log('index page.js on destroy invoke');
            }
        });
        ;
    })();
} catch (e) {
    console.log('Mini Program Error', e);
    e && e.stack && e.stack.split(/\n/).forEach(i => console.log('error stack', i));
    ;
}